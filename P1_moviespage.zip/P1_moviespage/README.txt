---------------------------README----------------------------------------------------

Project Name: Movie Trailer Website

Created on: 5/1/16

Author:  Adam Hussain

Included:
entertainment_center.py
fresh_tomatoes.py
fresh_tomatoes.html
media.py
README.txt

---------------Description---------------------------------------
This is a generated static web page that vistors can go to browse my favorite movies. Each movie will its movie poster, movie synopsis, and movie trailer once you click on the movie poster. This program was created using Python and the useful Python library "Fresh Tomatoes". Fresh Tomatoes creates a static movie page based on the data you input into file when calling the functions that are inside this library.

---------------Requirements--------------------------------------------
To run this project, you must have Python installed on your computer. Once, Python is installed then you open the entertainment_center.py file and run it within IDLE python editor. When the program is ran, your default web browser should open up to the "Fresh Tomatoes" generated movie web page.

---------------Functionality-------------------------------------------
This project works by through the main python file entertainment_center.py. This file contains all the movie information contain within an array. This main file will call upon functions within the imported file of media.py to format the data that can be supplied to the freshtomatoes.py file to create our movie web page.